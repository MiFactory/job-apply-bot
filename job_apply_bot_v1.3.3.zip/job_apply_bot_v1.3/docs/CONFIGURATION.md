# Configuration reference

All files are per profile: `data/profiles/<name>/`. Examples with fictive data: [`examples/`](../examples).

## profile.json

| Key | Meaning |
|---|---|
| `first_name`, `last_name`, `email` | Used for name / email fields |
| `phone`, `phone_country_code`, `phone_national` | Full number, `+32`, and the number without country code |
| `city`, `postal_code`, `country`, `address` | Address fields |
| `linkedin_url`, `website`, `headline` | Profile links / headline |
| `google_email` | Gmail used for *Continue with Google* |
| `years_experience_total` | Default answer to "how many years of experience…" |
| `years_by_skill` | `{"salesforce": 3}` — answer when the question mentions the skill |
| `salary_year_eur`, `salary_month_eur` | Expected salary |
| `notice_period`, `available_from` | Availability / notice questions |
| `authorized_to_work`, `needs_sponsorship`, `willing_relocate`, `driving_licence` | Yes/No questions |
| `languages` | `{"english": "Professional", ...}` — answer to language level questions |
| `education` | Education questions |
| `cv_files` | `{"en": path, "fr": path, "nl": path}` — CV used per ad language |
| `default_cv_lang` | CV used when the ad language has no CV |

## criteria.json

| Key | Meaning |
|---|---|
| `sites` | `["linkedin", "indeed"]` |
| `titles` | Job titles searched (one search each) |
| `locations` | Search locations |
| `exclude` | Words that reject an offer when found in the **title** |
| `exclude_companies` | Companies to skip |
| `must_have_any` | At least one keyword must appear in title/description (empty = off) |
| `title_must_match_any` | At least one word must appear in the title (empty = off) |
| `posted_within_days` | Freshness window |
| `easy_apply_only` | Only Easy Apply / Indeed Apply offers |
| `min_score` | Minimum score (1 = accept all that pass the filters) |
| `max_applications_per_day` | Daily cap across runs |
| `skip_languages` | Skip ads written in these languages (e.g. `["nl"]`) |
| `location_must_contain` | The offer location must contain one of these lowercase fragments (keeps results in your country) |
| `include_drafts` | `true` (default): saved-jobs runs also finish your LinkedIn drafts (*Brouillon*) |
| `answer_timeout_seconds` | How long to wait for YOUR answer to an unknown form question before the bot answers from your CV (default 30; 0 = wait forever; GUI: *Wait for my answer*) |
| `auto_answer` | `true` (default): answer unknown questions from CV / profile / earlier answers when you don't answer in time. Sensitive questions are never guessed. Guesses are listed as *auto* in `answers_auto.json` and orange in the GUI |
| `timeout_seconds` | How long a click / page may wait before the job is skipped (default 15; GUI: *Timeout per click / page*; CLI: `--timeout`) |
| `saved_jobs` | LinkedIn *Saved jobs*: `off` (default), `first` (saved jobs, then search) or `only` (GUI drop-down; CLI `--saved`) |
| `unsave_after_apply` | Remove a saved job from your Saved list once applied (never in dry-run) |
| `ask_user_when_unknown` | Ask for unknown questions (otherwise skip the job and log it) |

## motivation.json

`{"en": "…", "fr": "…"}` — placeholders `{title}`, `{company}`, `{full_name}`. Chosen by the language of the ad.

## answers.json

`{"normalised question": "answer"}` — filled by the GUI/CLI when you answer unknown questions. Keys are lower-case, punctuation removed. Edit or delete rows in the GUI right panel.

## applications.csv

`date;site;job_id;title;company;location;url;status;note` — `;`-separated for Excel (FR).

## schedule.json
Per profile (`data/profiles/<name>/schedule.json`), written by the GUI or `main.py schedule`.

| Key | Meaning |
|---|---|
| `enabled` | Schedule on/off |
| `days` | Weekdays, `0` = Monday … `6` = Sunday |
| `time` | Start hour, `"HH:MM"`, local time |
| `retry_minutes` | After a LinkedIn limit, test again every N minutes (default 5) |
| `retry_max_hours` | Stop retrying after this long (default 48), then wait for the next scheduled day |
| `max_per_run` | Applications per run |
